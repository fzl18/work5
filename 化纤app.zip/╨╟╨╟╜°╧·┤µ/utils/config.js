const version = '1.0.5';
export {
	version
}