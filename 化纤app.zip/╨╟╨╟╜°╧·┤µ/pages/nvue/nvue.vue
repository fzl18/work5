<template>
	<view class="content">
		nvue 页面，请使用手机预览
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.content{
		height: 80vh;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 40upx;
	}
</style>
